package com.lucifer.music

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Purple = Color(0xFFA970FF)
private val Background = Color(0xFF000000)
private val SurfaceDark = Color(0xFF111111)
private val TextMuted = Color(0xFF999999)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var isPlayingState by mutableStateOf(false)
    private var titleState by mutableStateOf("Choose a song")

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val listener = object : Player.Listener {
        override fun onEvents(p: Player, events: Player.Events) {
            isPlayingState = p.isPlaying
            titleState = p.mediaMetadata.title?.toString() ?: "Choose a song"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = PlayerHolder.get(this)
        player.addListener(listener)
        isPlayingState = player.isPlaying
        titleState = player.mediaMetadata.title?.toString() ?: "Choose a song"

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            LuciferApp(
                onPlayUris = { uris -> playUris(uris) },
                onPlayUrl = { url -> playUrl(url) },
                onToggle = { togglePlayback() },
                onStop = { player.pause(); player.seekTo(0); player.stop() },
                onPrev = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0) },
                onNext = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() },
                onEqChange = { index, value -> PlayerHolder.setLevel(index, value) },
                onEqReset = { PlayerHolder.resetLevels() },
                isPlaying = isPlayingState,
                nowPlaying = titleState,
                initialLevels = PlayerHolder.levels.toList()
            )
        }
    }

    private fun startPlaybackService() {
        startService(Intent(this, PlaybackService::class.java))
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Local audio"
    }

    private fun playUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val items = uris.map { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            MediaItem.Builder()
                .setUri(uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(displayName(uri)).build())
                .build()
        }
        player.setMediaItems(items)
        player.prepare()
        player.play()
        startPlaybackService()
    }

    private fun playUrl(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) return
        val item = MediaItem.Builder()
            .setUri(clean)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(clean.substringAfterLast('/').ifBlank { "Server stream" })
                    .build()
            )
            .build()
        player.setMediaItem(item)
        player.prepare()
        player.play()
        startPlaybackService()
    }

    private fun togglePlayback() {
        if (player.mediaItemCount == 0) return
        if (player.isPlaying) player.pause() else player.play()
    }

    override fun onDestroy() {
        player.removeListener(listener)
        // Keep playing in the background; only shut everything down if nothing is playing.
        if (!isChangingConfigurations && !player.playWhenReady) {
            stopService(Intent(this, PlaybackService::class.java))
            PlayerHolder.release()
        }
        super.onDestroy()
    }
}

@Composable
private fun LuciferApp(
    onPlayUris: (List<Uri>) -> Unit,
    onPlayUrl: (String) -> Unit,
    onToggle: () -> Unit,
    onStop: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onEqChange: (Int, Float) -> Unit,
    onEqReset: () -> Unit,
    isPlaying: Boolean,
    nowPlaying: String,
    initialLevels: List<Float>
) {
    var tab by remember { mutableStateOf(0) }
    var serverUrl by remember { mutableStateOf("") }
    val bands = listOf("20", "25", "31.5", "40", "50", "63", "80", "100", "125", "160", "200", "250", "315", "400", "500", "630", "800", "1k", "1.25k", "1.6k", "2k", "2.5k", "3.15k", "4k", "5k", "6.3k", "8k", "10k", "12.5k", "16k", "20k")
    var levels by remember { mutableStateOf(initialLevels) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onPlayUris(uris)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Background,
            surface = SurfaceDark,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF080808), contentColor = Purple) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Library") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Equalizer, null) }, label = { Text("Equalizer") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Cloud, null) }, label = { Text("Sources") })
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("LUCIFER", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("YOUR SOUND. YOUR CONTROL.", color = Purple, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Purple, modifier = Modifier.size(30.dp))
                    }
                }

                when (tab) {
                    0 -> {
                        item { SectionTitle("WELCOME BACK") }
                        item {
                            DarkCard {
                                Text("Music without limits.", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("Play music from your phone or your own server.", color = TextMuted)
                                Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.FolderOpen, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Choose music")
                                }
                            }
                        }
                        item { PlayerCard(nowPlaying, isPlaying, onPrev, onToggle, onNext, onStop) }
                        item {
                            DarkCard {
                                Text("QUICK ACCESS", color = Purple, fontWeight = FontWeight.Bold)
                                Text("31-band equalizer • Local library • Personal server", color = TextMuted)
                                OutlinedButton(onClick = { tab = 2 }, modifier = Modifier.fillMaxWidth()) { Text("Open equalizer") }
                            }
                        }
                    }
                    1 -> {
                        item { SectionTitle("YOUR LIBRARY") }
                        item {
                            DarkCard {
                                Text("Local music", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                Text("Select audio files stored on your phone.", color = TextMuted)
                                Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Browse audio files") }
                            }
                        }
                    }
                    2 -> {
                        item { SectionTitle("31-BAND EQUALIZER") }
                        item {
                            DarkCard {
                                Text("Adjust the sound", color = Purple, fontWeight = FontWeight.Bold)
                                Text("Range: -12 dB to +12 dB. Device support may vary.", color = TextMuted, fontSize = 12.sp)
                                bands.forEachIndexed { index, label ->
                                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, color = Color.White)
                                            Text("${levels[index].toInt()} dB", color = Purple)
                                        }
                                        Slider(
                                            value = levels[index],
                                            onValueChange = { value ->
                                                levels = levels.toMutableList().also { it[index] = value }
                                                onEqChange(index, value)
                                            },
                                            valueRange = -12f..12f,
                                            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
                                        )
                                    }
                                }
                                OutlinedButton(onClick = {
                                    levels = List(31) { 0f }
                                    onEqReset()
                                }, modifier = Modifier.fillMaxWidth()) { Text("Reset to flat") }
                            }
                        }
                    }
                    3 -> {
                        item { SectionTitle("YOUR MUSIC SOURCES") }
                        item {
                            DarkCard {
                                Text("Personal music server", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                Text("Paste a direct audio stream URL (for example, an HTTPS MP3 or FLAC stream).", color = TextMuted)
                                OutlinedTextField(
                                    value = serverUrl,
                                    onValueChange = { serverUrl = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("https://your-server.com/song.mp3") },
                                    singleLine = true
                                )
                                Button(onClick = {
                                    onPlayUrl(serverUrl)
                                }, modifier = Modifier.fillMaxWidth()) { Text("Connect and play") }
                                Text("Only direct playable audio URLs are supported in this first version. Server login and library browsing can be added later.", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Purple, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
}

@Composable
private fun DarkCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(20.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun PlayerCard(
    name: String,
    isPlaying: Boolean,
    onPrev: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onStop: () -> Unit
) {
    DarkCard {
        Text("NOW PLAYING", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
        Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onStop) { Icon(Icons.Default.Stop, "Stop", tint = Color.White) }
            IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            IconButton(onClick = onToggle) {
                Icon(if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, "Play or pause", tint = Purple, modifier = Modifier.size(58.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}
