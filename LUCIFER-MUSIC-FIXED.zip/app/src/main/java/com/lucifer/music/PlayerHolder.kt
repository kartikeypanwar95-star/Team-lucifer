package com.lucifer.music

import android.content.Context
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.ln

/** Single shared player + equalizer, used by both the UI and the background playback service. */
object PlayerHolder {
    private var player: ExoPlayer? = null
    private var equalizer: Equalizer? = null

    /** Slider values in dB (-12..+12) for the 31 UI bands. */
    val levels = FloatArray(31)

    private val targetHz = floatArrayOf(20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f)

    @Synchronized
    fun get(context: Context): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        p.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attachEqualizer(audioSessionId)
            }
        })
        player = p
        attachEqualizer(p.audioSessionId)
        return p
    }

    @Synchronized
    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        equalizer = null
        player?.release()
        player = null
    }

    @Synchronized
    fun setLevel(index: Int, valueDb: Float) {
        levels[index] = valueDb
        applyLevels()
    }

    @Synchronized
    fun resetLevels() {
        levels.fill(0f)
        applyLevels()
    }

    private fun attachEqualizer(sessionId: Int) {
        try { equalizer?.release() } catch (_: Exception) {}
        equalizer = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        try {
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            applyLevels()
        } catch (_: Exception) {
            equalizer = null
        }
    }

    /**
     * Android devices usually expose only ~5 hardware bands. Each of the 31 sliders is assigned
     * to the nearest hardware band (by log distance), and a band's gain is the average of its sliders.
     */
    private fun applyLevels() {
        val eq = equalizer ?: return
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (bandCount <= 0) return
            val minMb = eq.bandLevelRange[0].toInt()
            val maxMb = eq.bandLevelRange[1].toInt()
            // getCenterFreq returns milliHertz
            val centersHz = FloatArray(bandCount) { eq.getCenterFreq(it.toShort()) / 1000f }
            val sums = FloatArray(bandCount)
            val counts = IntArray(bandCount)
            for (i in targetHz.indices) {
                var nearest = 0
                var best = Float.MAX_VALUE
                for (b in 0 until bandCount) {
                    val d = abs(ln(centersHz[b].coerceAtLeast(1f) / targetHz[i]))
                    if (d < best) { best = d; nearest = b }
                }
                sums[nearest] += levels[i]
                counts[nearest]++
            }
            for (b in 0 until bandCount) {
                val avgDb = if (counts[b] > 0) sums[b] / counts[b] else 0f
                val mb = (avgDb * 100f).toInt().coerceIn(minMb, maxMb) // 1 dB = 100 millibels
                eq.setBandLevel(b.toShort(), mb.toShort())
            }
        } catch (_: Exception) {}
    }
}
